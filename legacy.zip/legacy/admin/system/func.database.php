<?php
	function SCDatabase(){
		global $scDb ;   
	}      
?> 