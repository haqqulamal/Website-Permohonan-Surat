<link rel="stylesheet" type="text/css" href="alert/sweetalert.css" />
<script type="text/javascript" src="alert/sweetalert.min.js"></script>
<script type="text/javascript" src="alert/bootstrap.min.js"></script>