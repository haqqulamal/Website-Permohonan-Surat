<?php
	echo $_GET['cSql'] ; 
?>