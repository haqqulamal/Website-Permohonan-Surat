<footer class="main-footer">
    <div class="pull-right hidden-xs"></div>
    <strong>Copyright &copy; 2024 - <?php echo date("Y") ?> SISTEM INFORMASI SURAT KEPEMILIKAN TANAH DAN SURAT PERIJINAN USAHA  </strong>
</footer>